// Spectra Browser Guard & YouTube AdShield - Manifest V3 Background Script
// Cross-browser: Works in Google Chrome, Microsoft Edge, Brave, and Mozilla Firefox.
// Synchronizes declarativeNetRequest rules and custom URL block rules with SpectraNetworkManager via Native Messaging.

const HOST_NAME = "com.spectranetworkmanager.browser_host";
const api = typeof browser !== "undefined" ? browser : chrome;

let nativePort = null;
let syncedWithNativeHost = false;

const DEFAULT_STANDALONE_RULES = [
  {
    id: 1,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||youtube.com/api/stats/ads*",
      resourceTypes: ["xmlhttprequest", "ping", "other"]
    }
  },
  {
    id: 2,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||youtube.com/pagead/*",
      resourceTypes: ["xmlhttprequest", "script", "image", "sub_frame", "other"]
    }
  },
  {
    id: 3,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||youtube.com/get_midroll_*",
      resourceTypes: ["xmlhttprequest", "other"]
    }
  },
  {
    id: 4,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||youtube.com/ptracking*",
      resourceTypes: ["xmlhttprequest", "image", "ping", "other"]
    }
  },
  {
    id: 5,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||doubleclick.net/*",
      initiatorDomains: ["youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com"],
      resourceTypes: ["xmlhttprequest", "script", "image", "sub_frame", "media", "other"]
    }
  },
  {
    id: 6,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||googlesyndication.com/*",
      initiatorDomains: ["youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com"],
      resourceTypes: ["xmlhttprequest", "script", "image", "sub_frame", "other"]
    }
  },
  {
    id: 7,
    priority: 1,
    action: { type: "block" },
    condition: {
      urlFilter: "||googleadservices.com/*",
      initiatorDomains: ["youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com"],
      resourceTypes: ["xmlhttprequest", "script", "image", "sub_frame", "other"]
    }
  }
];

async function ensureDefaultSettingsAndRules() {
  try {
    const stored = await api.storage.local.get([
      "spectraInitialized",
      "blockYouTubeAds",
      "blockYouTubeAnnotations",
      "blockYouTubeShorts",
      "showPlaceholder",
      "customRules"
    ]);

    if (!stored.spectraInitialized) {
      await api.storage.local.set({
        spectraInitialized: true,
        blockYouTubeAds: stored.blockYouTubeAds !== undefined ? stored.blockYouTubeAds : true,
        blockYouTubeAnnotations: stored.blockYouTubeAnnotations !== undefined ? stored.blockYouTubeAnnotations : true,
        blockYouTubeShorts: stored.blockYouTubeShorts !== undefined ? stored.blockYouTubeShorts : false,
        showPlaceholder: stored.showPlaceholder !== undefined ? stored.showPlaceholder : true,
        customRules: stored.customRules || []
      });
    }

    if (!syncedWithNativeHost && api.declarativeNetRequest) {
      try {
        const existing = await api.declarativeNetRequest.getDynamicRules();
        if (existing.length === 0) {
          await api.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [],
            addRules: DEFAULT_STANDALONE_RULES
          });
        }
      } catch (dnrErr) {
        console.warn("[Spectra Browser Guard] Standalone DNR init note:", dnrErr);
      }
    }
  } catch (err) {
    console.warn("[Spectra Browser Guard] Initialization fallback notice:", err);
  }
}

function connectNativeHost() {
  try {
    if (!api.runtime || !api.runtime.connectNative) {
      console.warn("[Spectra Browser Guard] Native messaging API unavailable in this context.");
      return;
    }

    nativePort = api.runtime.connectNative(HOST_NAME);

    nativePort.onMessage.addListener((msg) => {
      if (msg && msg.type === "rules_update") {
        syncedWithNativeHost = true;
        applyDynamicRules(msg);
      }
    });

    nativePort.onDisconnect.addListener(() => {
      nativePort = null;
    });

    nativePort.postMessage({ type: "get_rules" });
  } catch (e) {
    console.warn("[Spectra Browser Guard] Running in standalone mode (Native Host not connected):", e);
  }
}

async function applyDynamicRules(payload) {
  try {
    let addRules = [];
    if (payload.enabled && payload.rulesJson) {
      try {
        const parsed = JSON.parse(payload.rulesJson);
        if (Array.isArray(parsed)) {
          addRules = parsed;
        }
      } catch (err) {
        console.error("[Spectra Browser Guard] Invalid rulesJson:", err);
      }
    }

    if (api.declarativeNetRequest) {
      try {
        const existingRules = await api.declarativeNetRequest.getDynamicRules();
        const removeIds = existingRules.map(r => r.id);

        await api.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: removeIds,
          addRules: addRules
        });
      } catch (dnrErr) {
        console.warn("[Spectra Browser Guard] declarativeNetRequest update note:", dnrErr);
      }
    }

    const customRulesList = Array.isArray(payload.customRules) ? payload.customRules : [];

    await api.storage.local.set({
      spectraInitialized: true,
      showPlaceholder: payload.placeholder !== false,
      blockYouTubeAds: payload.blockYouTubeAds !== false,
      blockYouTubeAnnotations: payload.blockYouTubeAnnotations !== false,
      blockYouTubeShorts: payload.blockYouTubeShorts === true,
      activeRulesCount: addRules.length,
      customRules: customRulesList
    });

    // Notify all open tabs of updated rules so active videos/pages block immediately
    try {
      if (api.tabs && api.tabs.query) {
        const tabs = await api.tabs.query({});
        for (const tab of tabs) {
          if (tab.id) {
            api.tabs.sendMessage(tab.id, {
              type: "spectra_rules_updated",
              customRules: customRulesList,
              blockYouTubeShorts: payload.blockYouTubeShorts === true,
              blockYouTubeAds: payload.blockYouTubeAds !== false
            }).catch(() => {});
          }
        }
      }
    } catch {}
  } catch (err) {
    console.error("[Spectra Browser Guard] Failed to update dynamic rules:", err);
  }
}

api.runtime.onInstalled.addListener(() => {
  ensureDefaultSettingsAndRules();
  connectNativeHost();
});

api.runtime.onStartup.addListener(() => {
  ensureDefaultSettingsAndRules();
  connectNativeHost();
});

// Periodic sync every 15 seconds to pick up new rules from SpectraNetworkManager
setInterval(() => {
  if (!nativePort) {
    connectNativeHost();
  } else {
    try {
      nativePort.postMessage({ type: "get_rules" });
    } catch {
      nativePort = null;
    }
  }
}, 15000);

ensureDefaultSettingsAndRules();
connectNativeHost();
